import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useThree } from '@react-three/fiber';
import { GodRays } from '@react-three/postprocessing';

interface SunProps {
    distance?: number; // Distance of the Sun from the Earth
    speed?: number; // Speed of the Sun's movement
    radius?: number; // Radius of the Sun
}

export function Sun({ distance = 10, speed = 0.0002, radius = 1 }: SunProps) {
    const sunLightRef = useRef<THREE.DirectionalLight>(null);
    const sunMeshRef = useRef<THREE.Mesh>(null);
    const sunAngle = useRef(0);

    // Update Sunlight position dynamically
    useFrame(() => {
        if (sunLightRef.current && sunMeshRef.current) {
            sunAngle.current += speed;
            const x = distance * Math.cos(sunAngle.current);
            const z = distance * Math.sin(sunAngle.current * 0.5);
            sunLightRef.current.position.set(x, 0, z);
            sunMeshRef.current.position.set(x, 0, z);
        }
    });

    const { scene, camera } = useThree();

    // Add Sun glow effect using GodRays
    const sunGlowEffect = useMemo(() => {
        return (
            <GodRays
                sun={sunMeshRef.current}
                samples={100} // Increase for higher quality
                density={0.97}
                decay={0.9}
                weight={0.5}
                exposure={0.3}
                clampMax={1}
            />
        );
    }, [scene, camera]);

    return (
        <>
            {/* Directional Light */}
            <directionalLight
                ref={sunLightRef}
                color={0xffffff}
                intensity={3}
                castShadow
                shadow-mapSize-width={1024}
                shadow-mapSize-height={1024}
            />

            {/* Sun Sphere */}
            <mesh ref={sunMeshRef}>
                <sphereGeometry args={[radius, 32, 32]} />
                <meshBasicMaterial
                    color={new THREE.Color(0xffddaa)}
                    emissive={new THREE.Color(0xffddaa)}
                    emissiveIntensity={2}
                    toneMapped={false} // Prevent tone mapping from dulling the color
                />
            </mesh>

            {/* Sun Glow Effect */}
            {sunGlowEffect}
        </>
    );
}
